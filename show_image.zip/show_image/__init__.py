# -*- coding: utf-8 -*-
"""
QGIS File Loader Plugin with YOLO Model Support
"""

def classFactory(iface):
    """Load FileLoaderPlugin class from file file_loader_plugin.py"""
    from .file_loader_plugin import FileLoaderPlugin
    return FileLoaderPlugin(iface)