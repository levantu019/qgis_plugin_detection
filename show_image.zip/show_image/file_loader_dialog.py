# -*- coding: utf-8 -*-
"""
Main Dialog for File Loader Plugin
"""

import os
from qgis.PyQt.QtGui import QCursor
from qgis.PyQt import uic
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QMessageBox
from qgis.core import QgsProject

from .ui.dialog_ui import DialogUI
from .core.polygon_tool import PolygonMapTool
from .core.processing_thread import ProcessingThread
from .core.layer_loading_thread import LayerLoadingThread
from .utils.file_utils import FileUtils

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'file_loader_dialog_base.ui'))

class FileLoaderDialog(QDialog, FORM_CLASS):

    def __init__(self, iface, parent=None):
        """Constructor."""
        super(FileLoaderDialog, self).__init__(parent)
        
        # Initialize variables FIRST before setting up UI
        self.iface = iface
        self.raster_files = []
        self.model_file = None
        self.processing_thread = None
        self.layer_loading_thread = None
        self.folder_path = None
        self.drawn_polygon = None
        self.polygon_map_tool = None
        self.polygon_rubber_band = None
        
        # Set up the user interface from Designer through FORM_CLASS.
        self.setupUi(self)
        
        # Initialize custom UI
        self.ui_manager = DialogUI(self)
        self.ui_manager.setup_ui()

        # Set up button cursors
        self.setup_button_cursors()  # Add this line
        
        # Initialize file utilities
        self.file_utils = FileUtils()
        
    def close_plugin(self):
        """Close the plugin dialog"""
        # Clean up polygon drawing if active
        self.clear_polygon()
        
        # Cancel any running processing
        if self.processing_thread and self.processing_thread.isRunning():
            self.processing_thread.cancel()
            self.processing_thread.wait(3000)
            
        # Cancel any running layer loading
        if self.layer_loading_thread and self.layer_loading_thread.isRunning():
            self.layer_loading_thread.cancel()
            self.layer_loading_thread.wait(3000)
        
        self.close()
        
    def on_mode_changed(self):
        """Handle mode change between file and folder selection"""
        if self.file_mode_radio.isChecked():
            self.file_mode_group.setVisible(True)
            self.folder_mode_group.setVisible(False)
            self.clear_polygon()
        else:
            self.file_mode_group.setVisible(False)
            self.folder_mode_group.setVisible(True)
            
        self.update_ui_state()
        
    def browse_folder(self):
        """Browse for folder containing raster files"""
        folder = self.file_utils.browse_folder(self)
        if folder:
            self.folder_path = folder
            self.folder_path_edit.setText(folder)
            self.update_folder_contents()
        self.update_ui_state()
        
    def update_folder_contents(self):
        """Update the display of folder contents"""
        content_text = self.file_utils.get_folder_contents_text(self.folder_path)
        self.folder_contents_label.setText(content_text)
        
    def start_polygon_drawing(self):
        """Start polygon drawing mode"""
        if not self.iface:
            QMessageBox.warning(self, "Warning", "Map interface not available.")
            return
            
        canvas = self.iface.mapCanvas()
        self.polygon_map_tool = PolygonMapTool(canvas)
        self.polygon_map_tool.polygon_finished.connect(self.on_polygon_drawn)
        
        canvas.setMapTool(self.polygon_map_tool)
        
        # Update UI
        self.draw_polygon_btn.setText("✏️ Drawing... (Right-click to finish)")
        self.draw_polygon_btn.setStyleSheet("QPushButton { background-color: #FF9800; color: white; font-weight: bold; padding: 8px; }")
        self.polygon_status_label.setText("Left-click to add points, right-click to finish polygon")
        
        self.showMinimized()
        
    def on_polygon_drawn(self, geometry):
        """Handle when polygon is drawn"""
        from .ui.polygon_ui import PolygonUI
        polygon_ui = PolygonUI(self.iface)
        
        self.drawn_polygon = geometry
        
        if self.iface:
            self.iface.mapCanvas().unsetMapTool(self.polygon_map_tool)
        
        # Create and store rubber bands
        self.polygon_rubber_band, self.polygon_outline_band = polygon_ui.create_polygon_display(geometry)
        
        # Update UI
        self.draw_polygon_btn.setText("✏️ Draw Polygon on Map")
        self.draw_polygon_btn.setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; padding: 8px; }")
        
        # Show polygon info
        area = geometry.area()
        vertex_count = len(geometry.asPolygon()[0]) - 1
        self.polygon_status_label.setText(f"✅ Polygon drawn: {vertex_count} vertices, Area: {area:.2f} sq units")
        
        self.showNormal()
        self.raise_()
        self.activateWindow()
        self.update_ui_state()
        
    def clear_polygon(self):
        """Clear the drawn polygon"""
        from .ui.polygon_ui import PolygonUI
        polygon_ui = PolygonUI(self.iface)
        
        self.drawn_polygon = None
        self.polygon_status_label.setText("No polygon drawn")
        
        polygon_ui.clear_polygon_display(self.polygon_rubber_band, 
                                       getattr(self, 'polygon_outline_band', None))
        
        self.polygon_rubber_band = None
        if hasattr(self, 'polygon_outline_band'):
            self.polygon_outline_band = None
            
        if self.polygon_map_tool and self.iface:
            self.polygon_map_tool.reset()
            
        self.update_ui_state()
        
    def get_rasters_in_polygon(self):
        """Get raster files that intersect with the drawn polygon"""
        return self.file_utils.get_rasters_in_polygon(self.folder_path, self.drawn_polygon)
        
    def get_current_raster_files(self):
        """Get the current list of raster files based on selected mode"""
        if self.file_mode_radio.isChecked():
            return self.raster_files
        else:
            if self.drawn_polygon:
                return self.get_rasters_in_polygon()
            else:
                if self.folder_path:
                    return self.file_utils.get_all_rasters_in_folder(self.folder_path)
                else:
                    return []
        
    def add_raster_files(self):
        """Add raster files to the list"""
        files = self.file_utils.browse_raster_files(self)
        for file_path in files:
            if file_path not in self.raster_files:
                self.raster_files.append(file_path)
                self.raster_list.addItem(os.path.basename(file_path))
        self.update_ui_state()
        
    def remove_selected_raster(self):
        """Remove selected raster from list"""
        current_row = self.raster_list.currentRow()
        if current_row >= 0:
            self.raster_list.takeItem(current_row)
            del self.raster_files[current_row]
        self.update_ui_state()
        
    def clear_raster_files(self):
        """Clear all raster files"""
        self.raster_list.clear()
        self.raster_files = []
        self.update_ui_state()
        
    def browse_model_file(self):
        """Browse for YOLO model file"""
        file_path = self.file_utils.browse_model_file(self)
        if file_path:
            self.model_file = file_path
            self.model_path_edit.setText(file_path)
        self.update_ui_state()
        
    def clear_model_file(self):
        """Clear the selected model file"""
        self.model_file = None
        self.model_path_edit.setText("")
        self.update_ui_state()
        
    def update_ui_state(self):
        """Update UI based on current state"""
        if not hasattr(self, 'model_path_edit'):
            return
            
        current_rasters = self.get_current_raster_files()
        has_rasters = len(current_rasters) > 0
        has_model = bool(self.model_path_edit.text().strip())
        
        if has_model:
            self.process_btn.setVisible(True)
            self.show_layers_btn.setVisible(False)
            self.process_btn.setEnabled(has_rasters)
            
            if has_rasters:
                mode_text = "files" if self.file_mode_radio.isChecked() else "rasters in folder"
                if not self.file_mode_radio.isChecked() and self.drawn_polygon:
                    mode_text = "rasters intersecting polygon"
                self.status_label.setText(f"Ready to process {len(current_rasters)} {mode_text} with YOLO model")
            else:
                self.status_label.setText("Add raster files or select folder to begin processing with YOLO")
        else:
            self.process_btn.setVisible(False)
            self.show_layers_btn.setVisible(True)
            self.show_layers_btn.setEnabled(has_rasters)
            
            if has_rasters:
                mode_text = "layers" if self.file_mode_radio.isChecked() else "raster layers from folder"
                if not self.file_mode_radio.isChecked() and self.drawn_polygon:
                    mode_text = "raster layers intersecting polygon"
                self.status_label.setText(f"Ready to show {len(current_rasters)} {mode_text} in QGIS")
            else:
                self.status_label.setText("Add raster files or select folder to show layers")
    
    def show_raster_layers(self):
        """Show raster layers in QGIS with progress tracking"""
        current_rasters = self.get_current_raster_files()
        
        if not current_rasters:
            if self.file_mode_radio.isChecked():
                QMessageBox.warning(self, "Warning", "Please add at least one raster file.")
            else:
                QMessageBox.warning(self, "Warning", "Please select a folder containing raster files.")
            return
        
        # Show progress UI and start loading
        self._start_layer_loading(current_rasters, process_after=False)
        
    def start_processing(self):
        """Start processing the raster files"""
        current_rasters = self.get_current_raster_files()
        
        if not current_rasters:
            if self.file_mode_radio.isChecked():
                QMessageBox.warning(self, "Warning", "Please add at least one raster file.")
            else:
                QMessageBox.warning(self, "Warning", "Please select a folder containing raster files.")
            return
            
        # Start layer loading with processing after
        self._start_layer_loading(current_rasters, process_after=True)
        
    def _start_layer_loading(self, raster_files, process_after=False):
        """Start layer loading with progress tracking"""
        self.layer_loading_progress.setVisible(True)
        self.layer_loading_status.setVisible(True)
        self.show_layers_btn.setVisible(False)
        self.process_btn.setVisible(False)
        self.cancel_btn.setVisible(True)
        
        self.layer_loading_thread = LayerLoadingThread(raster_files)
        self.layer_loading_thread.layer_progress_updated.connect(self.update_layer_loading_progress)
        self.layer_loading_thread.layer_loaded.connect(self.on_layer_loaded)
        
        if process_after:
            self.layer_loading_thread.loading_finished.connect(self.on_layers_loaded_start_processing)
        else:
            self.layer_loading_thread.loading_finished.connect(self.on_layer_loading_finished)
            
        self.layer_loading_thread.start()
        
    def update_layer_loading_progress(self, progress, current_layer, current_index, total_count):
        """Update layer loading progress"""
        self.layer_loading_progress.setValue(progress)
        self.layer_loading_status.setText(f"Loading layer {current_index}/{total_count}: {current_layer}")
        
    def on_layer_loaded(self, layer, layer_name):
        """Handle when a single layer is loaded"""
        QgsProject.instance().addMapLayer(layer)
        
    def on_layer_loading_finished(self, added_layers, failed_layers):
        """Handle when all layers are loaded"""
        from .ui.results_ui import ResultsUI
        results_ui = ResultsUI()
        
        self._reset_layer_loading_ui()
        
        mode_text = results_ui.get_mode_text(self.file_mode_radio.isChecked(), self.drawn_polygon)
        results_text = results_ui.format_layer_results(added_layers, failed_layers, mode_text)
        
        self.results_text.setPlainText(results_text)
        self.status_label.setText(f"Added {len(added_layers)} raster layers to QGIS")
        
        results_ui.show_completion_message(self, added_layers, failed_layers)
        
    def on_layers_loaded_start_processing(self, added_layers, failed_layers):
        """Start YOLO processing after layers are loaded"""
        self.layer_loading_progress.setVisible(False)
        self.layer_loading_status.setVisible(False)
        
        self.overall_progress.setVisible(True)
        self.raster_progress.setVisible(True)
        
        current_rasters = self.get_current_raster_files()
        
        self.processing_thread = ProcessingThread(current_rasters, self.model_file)
        self.processing_thread.progress_updated.connect(self.update_overall_progress)
        self.processing_thread.raster_progress_updated.connect(self.update_raster_progress)
        self.processing_thread.processing_finished.connect(self.processing_completed)
        self.processing_thread.start()
        
    def cancel_processing(self):
        """Cancel the processing or layer loading"""
        if self.layer_loading_thread and self.layer_loading_thread.isRunning():
            self.layer_loading_thread.cancel()
            self.layer_loading_thread.wait()
            
        if self.processing_thread and self.processing_thread.isRunning():
            self.processing_thread.cancel()
            self.processing_thread.wait()
            
        self.reset_ui_after_processing()
        self.status_label.setText("Operation cancelled")
        
    def update_overall_progress(self, progress, status, current, total):
        """Update overall progress"""
        self.overall_progress.setValue(progress)
        self.status_label.setText(status)
        
    def update_raster_progress(self, progress, filename):
        """Update current raster progress"""
        self.raster_progress.setValue(progress)
        
    def processing_completed(self, detections):
        """Handle completed processing"""
        from .ui.results_ui import ResultsUI
        from .core.detection_layer import DetectionLayerCreator
        
        self.reset_ui_after_processing()
        
        if detections:
            creator = DetectionLayerCreator()
            creator.create_detection_layer(detections)
            
        results_ui = ResultsUI()
        mode_text = results_ui.get_mode_text(self.file_mode_radio.isChecked(), self.drawn_polygon)
        results_text = results_ui.format_processing_results(detections, len(self.get_current_raster_files()), mode_text)
        
        self.results_text.setPlainText(results_text)
        self.status_label.setText("Processing completed successfully!")
        
        QMessageBox.information(self, "Success", 
                              f"Processing completed!\n{len(detections)} objects detected across {len(self.get_current_raster_files())} raster files.")
        
    def _reset_layer_loading_ui(self):
        """Reset layer loading UI elements"""
        self.layer_loading_progress.setVisible(False)
        self.layer_loading_status.setVisible(False)
        self.cancel_btn.setVisible(False)
        self.update_ui_state()
        
    def reset_ui_after_processing(self):
        """Reset UI after processing"""
        self.update_ui_state()
        self.cancel_btn.setVisible(False)
        self.layer_loading_progress.setVisible(False)
        self.layer_loading_status.setVisible(False)
        self.overall_progress.setVisible(False)
        self.raster_progress.setVisible(False)
        self.overall_progress.setValue(0)
        self.raster_progress.setValue(0)
        self.layer_loading_progress.setValue(0)
        
    def closeEvent(self, event):
        """Handle dialog close event"""
        self.clear_polygon()
        
        if self.processing_thread and self.processing_thread.isRunning():
            self.processing_thread.cancel()
            self.processing_thread.wait(3000)
            
        if self.layer_loading_thread and self.layer_loading_thread.isRunning():
            self.layer_loading_thread.cancel()
            self.layer_loading_thread.wait(3000)
            
        event.accept()

    # Add this method to your FileLoaderDialog class
    def setup_button_cursors(self):
        """Setup hand cursors for main action buttons"""
        hand_cursor = QCursor(Qt.PointingHandCursor)
        self.process_btn.setCursor(hand_cursor)
        self.show_layers_btn.setCursor(hand_cursor)