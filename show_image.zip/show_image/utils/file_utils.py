# -*- coding: utf-8 -*-
"""
File Utilities
"""

import os
import glob
from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
from qgis.core import QgsRasterLayer, QgsGeometry

class FileUtils:
    """Utility functions for file operations"""
    
    def browse_folder(self, parent):
        """Browse for folder containing raster files"""
        return QFileDialog.getExistingDirectory(
            parent,
            "Select Folder Containing Raster Files",
            ""
        )
        
    def browse_raster_files(self, parent):
        """Browse for individual raster files"""
        files, _ = QFileDialog.getOpenFileNames(
            parent,
            "Select Raster Files",
            "",
            "GeoTIFF files (*.tif *.tiff);;All files (*.*)"
        )
        return files
        
    def browse_model_file(self, parent):
        """Browse for YOLO model file"""
        file_path, _ = QFileDialog.getOpenFileName(
            parent,
            "Select YOLO Model File",
            "",
            "PyTorch Model files (*.pt);;All files (*.*)"
        )
        return file_path
        
    def get_folder_contents_text(self, folder_path):
        """Get folder contents description text"""
        if not folder_path:
            return "Folder contents will be shown here..."
            
        raster_files = self.get_all_rasters_in_folder(folder_path)
        
        if raster_files:
            content_text = f"📁 Found {len(raster_files)} raster file(s):\n"
            for i, file_path in enumerate(raster_files[:10]):  # Show first 10 files
                filename = os.path.basename(file_path)
                content_text += f"  • {filename}\n"
            
            if len(raster_files) > 10:
                content_text += f"  ... and {len(raster_files) - 10} more files"
        else:
            content_text = "❌ No raster files (.tif/.tiff) found in selected folder"
            
        return content_text
        
    def get_all_rasters_in_folder(self, folder_path):
        """Get all raster files in a folder (case-insensitive, avoiding duplicates)"""
        if not folder_path:
            return []
            
        raster_files = []
        
        try:
            # Get all files in the directory
            all_files = os.listdir(folder_path)
            
            # Filter for raster files (case-insensitive)
            valid_extensions = {'.tif', '.tiff'}
            
            for file in all_files:
                file_ext = os.path.splitext(file)[1].lower()  # Convert to lowercase for comparison
                if file_ext in valid_extensions:
                    full_path = os.path.join(folder_path, file)
                    raster_files.append(full_path)
                    
            # Sort for consistent ordering
            raster_files.sort()
            
        except OSError as e:
            print(f"Error reading directory {folder_path}: {e}")
            
        return raster_files
        
    def get_rasters_in_polygon(self, folder_path, polygon):
        """Get raster files that intersect with the drawn polygon"""
        if not folder_path or not polygon:
            return []
            
        all_raster_files = self.get_all_rasters_in_folder(folder_path)
        intersecting_rasters = []
        
        for raster_file in all_raster_files:
            try:
                temp_layer = QgsRasterLayer(raster_file, "temp")
                if temp_layer.isValid():
                    raster_extent = temp_layer.extent()
                    raster_geometry = QgsGeometry.fromRect(raster_extent)
                    
                    if polygon.intersects(raster_geometry):
                        intersecting_rasters.append(raster_file)
            except Exception as e:
                print(f"Error checking raster {raster_file}: {e}")
                continue
                
        return intersecting_rasters