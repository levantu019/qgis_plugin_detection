# -*- coding: utf-8 -*-
"""
Polygon Drawing Tool
"""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtGui import QColor
from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand
from qgis.core import QgsGeometry, QgsWkbTypes

class PolygonMapTool(QgsMapToolEmitPoint):
    """Custom map tool for drawing polygons"""
    polygon_finished = pyqtSignal(object)  # Emits QgsGeometry
    
    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.points = []
        self.rubber_band = None
        self.temp_rubber_band = None
        self.is_capturing = False
        
    def canvasPressEvent(self, event):
        """Handle mouse press events"""
        if event.button() == Qt.LeftButton:
            point = self.toMapCoordinates(event.pos())
            self.points.append(point)
            
            if not self.is_capturing:
                self.start_capturing()
            
            self.update_rubber_band()
            
        elif event.button() == Qt.RightButton:
            if len(self.points) >= 3:
                self.finish_polygon()
            else:
                QMessageBox.warning(None, "Warning", "A polygon needs at least 3 points.")
    
    def canvasMoveEvent(self, event):
        """Handle mouse move events"""
        if self.is_capturing and len(self.points) > 0:
            current_point = self.toMapCoordinates(event.pos())
            if self.temp_rubber_band:
                self.temp_rubber_band.reset(QgsWkbTypes.LineGeometry)
                self.temp_rubber_band.addPoint(self.points[-1])
                self.temp_rubber_band.addPoint(current_point)
    
    def start_capturing(self):
        """Start capturing polygon"""
        self.is_capturing = True
        
        self.rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.PolygonGeometry)
        self.rubber_band.setColor(QColor(255, 0, 0, 100))
        self.rubber_band.setWidth(2)
        
        self.temp_rubber_band = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.temp_rubber_band.setColor(QColor(255, 0, 0, 150))
        self.temp_rubber_band.setWidth(1)
        self.temp_rubber_band.setLineStyle(Qt.DashLine)
    
    def update_rubber_band(self):
        """Update the rubber band display"""
        if self.rubber_band:
            self.rubber_band.reset(QgsWkbTypes.PolygonGeometry)
            for point in self.points:
                self.rubber_band.addPoint(point)
    
    def finish_polygon(self):
        """Finish polygon creation"""
        if len(self.points) >= 3:
            closed_points = self.points + [self.points[0]]
            geometry = QgsGeometry.fromPolygonXY([closed_points])
            self.cleanup()
            self.polygon_finished.emit(geometry)
    
    def cleanup(self):
        """Clean up rubber bands and reset state"""
        if self.rubber_band:
            self.canvas.scene().removeItem(self.rubber_band)
            self.rubber_band = None
            
        if self.temp_rubber_band:
            self.canvas.scene().removeItem(self.temp_rubber_band)
            self.temp_rubber_band = None
            
        self.points = []
        self.is_capturing = False
    
    def reset(self):
        """Reset the tool"""
        self.cleanup()