# -*- coding: utf-8 -*-
"""
Layer Loading Thread
"""

import os
import time
from qgis.PyQt.QtCore import QThread, pyqtSignal
from qgis.core import QgsRasterLayer

class LayerLoadingThread(QThread):
    """Thread for loading raster layers with progress tracking"""
    layer_progress_updated = pyqtSignal(int, str, int, int)  # progress, current_layer_name, current_index, total_count
    layer_loaded = pyqtSignal(object, str)  # layer, layer_name
    loading_finished = pyqtSignal(list, list)  # added_layers, failed_layers
    
    def __init__(self, raster_files):
        super().__init__()
        self.raster_files = raster_files
        self.is_cancelled = False
        
    def cancel(self):
        self.is_cancelled = True
        
    def run(self):
        """Load raster layers with progress updates"""
        total_files = len(self.raster_files)
        added_layers = []
        failed_layers = []
        
        for i, raster_file in enumerate(self.raster_files):
            if self.is_cancelled:
                break
                
            filename = os.path.basename(raster_file)
            layer_name = os.path.splitext(filename)[0]
            
            progress = int((i / total_files) * 100)
            self.layer_progress_updated.emit(progress, layer_name, i + 1, total_files)
            
            try:
                raster_layer = QgsRasterLayer(raster_file, layer_name)
                
                if raster_layer.isValid():
                    self.layer_loaded.emit(raster_layer, layer_name)
                    added_layers.append(layer_name)
                    time.sleep(0.1)  # Small delay for visual feedback
                else:
                    failed_layers.append(filename)
                    
            except Exception as e:
                print(f"Error loading raster {raster_file}: {e}")
                failed_layers.append(filename)
                continue
        
        if not self.is_cancelled:
            self.layer_progress_updated.emit(100, "Loading completed!", total_files, total_files)
            self.loading_finished.emit(added_layers, failed_layers)