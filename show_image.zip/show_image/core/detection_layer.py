# -*- coding: utf-8 -*-
"""
Detection Layer Creation
"""

from qgis.core import (QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY, 
                       QgsProject, QgsField, QgsFields)
from qgis.PyQt.QtCore import QVariant

class DetectionLayerCreator:
    """Creates vector layers for YOLO detections"""
    
    def create_detection_layer(self, detections):
        """Create a vector layer with detection points"""
        # Define fields
        fields = QgsFields()
        fields.append(QgsField("id", QVariant.Int))
        fields.append(QgsField("confidence", QVariant.Double))
        fields.append(QgsField("class", QVariant.String))
        fields.append(QgsField("source_raster", QVariant.String))
        
        # Create layer
        layer = QgsVectorLayer("Point?crs=EPSG:4326", "YOLO Detections", "memory")
        layer.dataProvider().addAttributes(fields)
        layer.updateFields()
        
        # Add features
        features = []
        for detection in detections:
            feature = QgsFeature()
            feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(detection['x'], detection['y'])))
            feature.setAttributes([
                detection['id'],
                detection['confidence'],
                detection['class'],
                detection['source_raster']
            ])
            features.append(feature)
            
        layer.dataProvider().addFeatures(features)
        layer.updateExtents()
        
        # Add to project
        QgsProject.instance().addMapLayer(layer)