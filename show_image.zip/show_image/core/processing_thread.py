# -*- coding: utf-8 -*-
"""
YOLO Processing Thread
"""

import os
import time
import random
from qgis.PyQt.QtCore import QThread, pyqtSignal

class ProcessingThread(QThread):
    """Thread for processing raster files with YOLO model"""
    progress_updated = pyqtSignal(int, str, int, int)  # overall_progress, status_message, current_raster, total_rasters
    raster_progress_updated = pyqtSignal(int, str)  # raster_progress, raster_name
    processing_finished = pyqtSignal(list)  # results
    
    def __init__(self, raster_files, model_file=None):
        super().__init__()
        self.raster_files = raster_files
        self.model_file = model_file
        self.is_cancelled = False
        
    def cancel(self):
        self.is_cancelled = True
        
    def run(self):
        """Process each raster file"""
        total_files = len(self.raster_files)
        all_detections = []
        
        for i, raster_file in enumerate(self.raster_files):
            if self.is_cancelled:
                break
                
            filename = os.path.basename(raster_file)
            self.progress_updated.emit(
                int((i / total_files) * 100),
                f"Processing raster {i+1}/{total_files}: {filename}",
                i + 1,
                total_files
            )
            
            # Simulate processing each raster
            for progress in range(0, 101, 5):
                if self.is_cancelled:
                    break
                self.raster_progress_updated.emit(progress, filename)
                time.sleep(0.1)
            
            if not self.is_cancelled:
                # Simulate detections for this raster
                num_detections = random.randint(5, 20)
                for j in range(num_detections):
                    detection = {
                        'id': len(all_detections) + 1,
                        'x': random.uniform(-180, 180),
                        'y': random.uniform(-90, 90),
                        'confidence': random.uniform(0.5, 0.99),
                        'class': random.choice(['building', 'vehicle', 'tree', 'road']),
                        'source_raster': filename
                    }
                    all_detections.append(detection)
        
        if not self.is_cancelled:
            self.progress_updated.emit(100, "Processing completed!", total_files, total_files)
            self.processing_finished.emit(all_detections)