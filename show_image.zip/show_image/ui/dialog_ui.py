# -*- coding: utf-8 -*-
"""
UI Setup and Management for File Loader Dialog
"""

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QVBoxLayout, QHBoxLayout, QGroupBox, 
                                 QListWidget, QPushButton, QLabel, 
                                 QProgressBar, QTextEdit, QLineEdit,
                                 QRadioButton, QButtonGroup)

class DialogUI:
    """Manages the UI setup for the main dialog"""
    
    def __init__(self, dialog):
        self.dialog = dialog
        
    def setup_ui(self):
        """Setup the complete UI"""
        if self.dialog.layout():
            self.dialog.layout().deleteLater()
        
        main_layout = QVBoxLayout()
        self.dialog.setLayout(main_layout)
        
        self._setup_title(main_layout)
        self._setup_mode_selection(main_layout)
        self._setup_file_mode_section(main_layout)
        self._setup_folder_mode_section(main_layout)
        self._setup_model_section(main_layout)
        self._setup_processing_section(main_layout)
        self._setup_results_section(main_layout)
        self._setup_close_button(main_layout)
        
        self.dialog.resize(700, 1050)
        
        # Connect signals
        self.dialog.model_path_edit.textChanged.connect(self.dialog.update_ui_state)
        self.dialog.update_ui_state()
        
    def _setup_title(self, main_layout):
        """Setup title section"""
        title_label = QLabel("🗺️ QGIS Raster File Loader with YOLO Object Detection")
        title_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #2E7D32; margin: 10px;")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)
        
    def _setup_mode_selection(self, main_layout):
        """Setup mode selection section"""
        mode_group = QGroupBox("🔧 Processing Mode")
        mode_layout = QVBoxLayout()
        
        self.dialog.mode_button_group = QButtonGroup()
        self.dialog.file_mode_radio = QRadioButton("📁 Select Individual Files")
        self.dialog.folder_mode_radio = QRadioButton("📂 Select Folder + Draw Polygon")
        
        self.dialog.file_mode_radio.setChecked(True)
        self.dialog.mode_button_group.addButton(self.dialog.file_mode_radio, 0)
        self.dialog.mode_button_group.addButton(self.dialog.folder_mode_radio, 1)
        
        self.dialog.file_mode_radio.toggled.connect(self.dialog.on_mode_changed)
        self.dialog.folder_mode_radio.toggled.connect(self.dialog.on_mode_changed)
        
        mode_layout.addWidget(self.dialog.file_mode_radio)
        mode_layout.addWidget(self.dialog.folder_mode_radio)
        mode_group.setLayout(mode_layout)
        main_layout.addWidget(mode_group)
        
    def _setup_file_mode_section(self, main_layout):
        """Setup file mode section"""
        self.dialog.file_mode_group = QGroupBox("📁 Individual Raster Files (.tif)")
        file_mode_layout = QVBoxLayout()
        
        self.dialog.raster_list = QListWidget()
        self.dialog.raster_list.setMinimumHeight(120)
        file_mode_layout.addWidget(self.dialog.raster_list)
        
        raster_buttons_layout = QHBoxLayout()
        self.dialog.add_raster_btn = QPushButton("➕ Add Raster Files")
        self.dialog.remove_raster_btn = QPushButton("➖ Remove Selected")
        self.dialog.clear_raster_btn = QPushButton("🗑️ Clear All")
        
        self.dialog.add_raster_btn.clicked.connect(self.dialog.add_raster_files)
        self.dialog.remove_raster_btn.clicked.connect(self.dialog.remove_selected_raster)
        self.dialog.clear_raster_btn.clicked.connect(self.dialog.clear_raster_files)
        
        raster_buttons_layout.addWidget(self.dialog.add_raster_btn)
        raster_buttons_layout.addWidget(self.dialog.remove_raster_btn)
        raster_buttons_layout.addWidget(self.dialog.clear_raster_btn)
        file_mode_layout.addLayout(raster_buttons_layout)
        
        self.dialog.file_mode_group.setLayout(file_mode_layout)
        main_layout.addWidget(self.dialog.file_mode_group)
        
    def _setup_folder_mode_section(self, main_layout):
        """Setup folder mode section"""
        self.dialog.folder_mode_group = QGroupBox("📂 Folder Selection + Polygon Drawing")
        folder_mode_layout = QVBoxLayout()
        
        # Folder selection
        folder_selection_layout = QHBoxLayout()
        self.dialog.folder_path_edit = QLineEdit()
        self.dialog.folder_path_edit.setPlaceholderText("Select folder containing raster files")
        self.dialog.folder_path_edit.setReadOnly(True)
        self.dialog.browse_folder_btn = QPushButton("📂 Browse Folder")
        self.dialog.browse_folder_btn.clicked.connect(self.dialog.browse_folder)
        
        folder_selection_layout.addWidget(self.dialog.folder_path_edit)
        folder_selection_layout.addWidget(self.dialog.browse_folder_btn)
        folder_mode_layout.addLayout(folder_selection_layout)
        
        # Polygon drawing
        polygon_layout = QHBoxLayout()
        self.dialog.draw_polygon_btn = QPushButton("✏️ Draw Polygon on Map")
        self.dialog.clear_polygon_btn = QPushButton("🗑️ Clear Polygon")
        self.dialog.polygon_status_label = QLabel("No polygon drawn")
        self.dialog.polygon_status_label.setStyleSheet("color: #757575; font-style: italic;")
        
        self.dialog.draw_polygon_btn.clicked.connect(self.dialog.start_polygon_drawing)
        self.dialog.clear_polygon_btn.clicked.connect(self.dialog.clear_polygon)
        
        polygon_layout.addWidget(self.dialog.draw_polygon_btn)
        polygon_layout.addWidget(self.dialog.clear_polygon_btn)
        polygon_layout.addWidget(self.dialog.polygon_status_label)
        folder_mode_layout.addLayout(polygon_layout)
        
        # Instructions
        instructions_label = QLabel("Instructions: Left-click to add points, Right-click to finish polygon (minimum 3 points)")
        instructions_label.setStyleSheet("color: #666; font-size: 10px; font-style: italic; padding: 5px;")
        instructions_label.setWordWrap(True)
        folder_mode_layout.addWidget(instructions_label)
        
        # Folder contents display
        self.dialog.folder_contents_label = QLabel("Folder contents will be shown here...")
        self.dialog.folder_contents_label.setStyleSheet("color: #757575; font-style: italic; padding: 10px; border: 1px dashed #ccc;")
        self.dialog.folder_contents_label.setMinimumHeight(80)
        self.dialog.folder_contents_label.setWordWrap(True)
        folder_mode_layout.addWidget(self.dialog.folder_contents_label)
        
        self.dialog.folder_mode_group.setLayout(folder_mode_layout)
        self.dialog.folder_mode_group.setVisible(False)
        main_layout.addWidget(self.dialog.folder_mode_group)
        
    def _setup_model_section(self, main_layout):
        """Setup YOLO model section"""
        model_group = QGroupBox("🤖 YOLO Model (Optional)")
        model_layout = QVBoxLayout()
        
        model_file_layout = QHBoxLayout()
        self.dialog.model_path_edit = QLineEdit()
        self.dialog.model_path_edit.setPlaceholderText("Select YOLO model file (.pt)")
        self.dialog.browse_model_btn = QPushButton("📂 Browse")
        self.dialog.browse_model_btn.clicked.connect(self.dialog.browse_model_file)
        
        self.dialog.clear_model_btn = QPushButton("🗑️ Clear")
        self.dialog.clear_model_btn.clicked.connect(self.dialog.clear_model_file)
        
        model_file_layout.addWidget(self.dialog.model_path_edit)
        model_file_layout.addWidget(self.dialog.browse_model_btn)
        model_file_layout.addWidget(self.dialog.clear_model_btn)
        model_layout.addLayout(model_file_layout)
        
        model_group.setLayout(model_layout)
        main_layout.addWidget(model_group)
        
    def _setup_processing_section(self, main_layout):
        """Setup processing section"""
        processing_group = QGroupBox("⚡ Processing")
        processing_layout = QVBoxLayout()
        
        # Layer Loading Progress
        self.dialog.layer_loading_progress = QProgressBar()
        self.dialog.layer_loading_progress.setVisible(False)
        processing_layout.addWidget(QLabel("Layer Loading Progress:"))
        processing_layout.addWidget(self.dialog.layer_loading_progress)
        
        self.dialog.layer_loading_status = QLabel("Ready to load layers")
        self.dialog.layer_loading_status.setStyleSheet("color: #2196F3; font-weight: bold;")
        self.dialog.layer_loading_status.setVisible(False)
        processing_layout.addWidget(self.dialog.layer_loading_status)
        
        # YOLO Processing Progress
        self.dialog.overall_progress = QProgressBar()
        self.dialog.overall_progress.setVisible(False)
        processing_layout.addWidget(QLabel("Overall Progress:"))
        processing_layout.addWidget(self.dialog.overall_progress)
        
        self.dialog.raster_progress = QProgressBar()
        self.dialog.raster_progress.setVisible(False)
        processing_layout.addWidget(QLabel("Current Raster Progress:"))
        processing_layout.addWidget(self.dialog.raster_progress)
        
        # Status
        self.dialog.status_label = QLabel("Ready to process files")
        self.dialog.status_label.setStyleSheet("color: #1976D2; font-weight: bold;")
        processing_layout.addWidget(self.dialog.status_label)
        
        # Action buttons with hover effects
        button_layout = QHBoxLayout()
        
        # Start Processing button with red hover effect
        self.dialog.process_btn = QPushButton("🚀 Start Processing")
        self.dialog.process_btn.clicked.connect(self.dialog.start_processing)
        self.dialog.process_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            QPushButton:hover {
                background-color: #f44336;
                cursor: pointer;
            }
            QPushButton:pressed {
                background-color: #d32f2f;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
                cursor: not-allowed;
            }
        """)
        
        # Show Layers button with red hover effect
        self.dialog.show_layers_btn = QPushButton("🗺️ Show Layers")
        self.dialog.show_layers_btn.clicked.connect(self.dialog.show_raster_layers)
        self.dialog.show_layers_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            QPushButton:hover {
                background-color: #f44336;
                cursor: pointer;
            }
            QPushButton:pressed {
                background-color: #d32f2f;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
                cursor: not-allowed;
            }
        """)
        
        # Cancel button
        self.dialog.cancel_btn = QPushButton("❌ Cancel")
        self.dialog.cancel_btn.clicked.connect(self.dialog.cancel_processing)
        self.dialog.cancel_btn.setVisible(False)
        self.dialog.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                font-weight: bold;
                padding: 8px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
            }
            QPushButton:hover {
                background-color: #d32f2f;
                cursor: pointer;
            }
            QPushButton:pressed {
                background-color: #b71c1c;
            }
        """)
        
        button_layout.addWidget(self.dialog.process_btn)
        button_layout.addWidget(self.dialog.show_layers_btn)
        button_layout.addWidget(self.dialog.cancel_btn)
        processing_layout.addLayout(button_layout)
        
        processing_group.setLayout(processing_layout)
        main_layout.addWidget(processing_group)
        
    def _setup_results_section(self, main_layout):
        """Setup results section"""
        results_group = QGroupBox("📊 Results")
        results_layout = QVBoxLayout()
        
        self.dialog.results_text = QTextEdit()
        self.dialog.results_text.setMaximumHeight(100)
        self.dialog.results_text.setPlainText("No processing completed yet.")
        results_layout.addWidget(self.dialog.results_text)
        
        results_group.setLayout(results_layout)
        main_layout.addWidget(results_group)
        
    def _setup_close_button(self, main_layout):
        """Setup close button"""
        close_section_layout = QHBoxLayout()
        close_section_layout.addStretch()
        
        self.dialog.close_btn = QPushButton("❌ Close Plugin")
        self.dialog.close_btn.clicked.connect(self.dialog.close_plugin)
        self.dialog.close_btn.setStyleSheet("""
            QPushButton {
                background-color: #607D8B;
                color: white;
                font-weight: bold;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                margin: 10px;
                cursor: pointer;
            }
            QPushButton:hover {
                background-color: #546E7A;
                cursor: pointer;
            }
            QPushButton:pressed {
                background-color: #455A64;
            }
        """)
        
        close_section_layout.addWidget(self.dialog.close_btn)
        main_layout.addLayout(close_section_layout)