# -*- coding: utf-8 -*-
"""
Results UI Management
"""

from qgis.PyQt.QtWidgets import QMessageBox

class ResultsUI:
    """Manages results display and formatting"""
    
    def get_mode_text(self, is_file_mode, has_polygon):
        """Get mode description text"""
        if is_file_mode:
            return "Individual Files"
        else:
            return "Folder (Polygon Filtered)" if has_polygon else "Folder"
            
    def format_layer_results(self, added_layers, failed_layers, mode_text):
        """Format layer loading results"""
        results_text = f"📊 Raster Layers Added to QGIS! (Mode: {mode_text})\n"
        results_text += f"✅ Successfully added: {len(added_layers)} layers\n"
        if failed_layers:
            results_text += f"❌ Failed to load: {len(failed_layers)} layers\n"
        
        results_text += f"\n📁 Added layers:\n"
        for layer in added_layers:
            results_text += f"  • {layer}\n"
        
        if failed_layers:
            results_text += f"\n❌ Failed layers:\n"
            for layer in failed_layers:
                results_text += f"  • {layer}\n"
                
        return results_text
        
    def format_processing_results(self, detections, files_processed, mode_text):
        """Format processing results"""
        total_detections = len(detections)
        
        results_text = f"✅ Processing Completed! (Mode: {mode_text})\n"
        results_text += f"📁 Files processed: {files_processed}\n"
        results_text += f"🎯 Total detections: {total_detections}\n"
        results_text += f"📊 Average detections per file: {total_detections/files_processed:.1f}"
        
        return results_text
        
    def show_completion_message(self, parent, added_layers, failed_layers):
        """Show completion message dialog"""
        if failed_layers:
            QMessageBox.warning(
                parent, 
                "Partial Success", 
                f"Added {len(added_layers)} layers successfully.\n{len(failed_layers)} layers failed to load."
            )
        else:
            QMessageBox.information(
                parent, 
                "Success", 
                f"Successfully added {len(added_layers)} raster layers to QGIS!"
            )