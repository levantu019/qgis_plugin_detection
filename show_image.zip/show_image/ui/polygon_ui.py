# -*- coding: utf-8 -*-
"""
Polygon UI Management
"""

from qgis.gui import QgsRubberBand
from qgis.core import QgsWkbTypes
from qgis.PyQt.QtGui import QColor

class PolygonUI:
    """Manages polygon display on the map"""
    
    def __init__(self, iface):
        self.iface = iface
        
    def create_polygon_display(self, geometry):
        """Create rubber bands to display the polygon"""
        if not self.iface:
            return None, None
            
        # Main polygon with fill
        polygon_rubber_band = QgsRubberBand(self.iface.mapCanvas(), QgsWkbTypes.PolygonGeometry)
        polygon_rubber_band.setToGeometry(geometry)
        polygon_rubber_band.setColor(QColor(0, 255, 0, 100))  # Green with transparency
        polygon_rubber_band.setWidth(3)
        
        # Outline polygon
        outline_rubber_band = QgsRubberBand(self.iface.mapCanvas(), QgsWkbTypes.PolygonGeometry)
        outline_rubber_band.setToGeometry(geometry)
        outline_rubber_band.setColor(QColor(0, 255, 0, 0))  # Transparent fill
        outline_rubber_band.setWidth(2)
        outline_rubber_band.setFillColor(QColor(0, 0, 0, 0))  # No fill, just outline
        
        return polygon_rubber_band, outline_rubber_band
        
    def clear_polygon_display(self, polygon_rubber_band, outline_rubber_band):
        """Clear polygon rubber bands from map"""
        if not self.iface:
            return
            
        if polygon_rubber_band:
            self.iface.mapCanvas().scene().removeItem(polygon_rubber_band)
            
        if outline_rubber_band:
            self.iface.mapCanvas().scene().removeItem(outline_rubber_band)