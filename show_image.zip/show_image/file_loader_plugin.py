# -*- coding: utf-8 -*-
"""
QGIS File Loader Plugin with YOLO Model Support
"""

import os
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsProject
from .file_loader_dialog import FileLoaderDialog

class FileLoaderPlugin:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor."""
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u'&File Loader')
        self.toolbar = self.iface.addToolBar(u'File Loader')
        self.toolbar.setObjectName(u'File Loader')
        self.first_start = None

    def tr(self, message):
        """Get the translation for a string using Qt translation API."""
        return QCoreApplication.translate('FileLoaderPlugin', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar."""

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Add to our custom toolbar instead of the plugins toolbar
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)
        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        # Get the icon path - you'll need to create this icon file
        icon_path = os.path.join(self.plugin_dir, 'icon.png')
        
        # If icon doesn't exist, create a default one programmatically
        if not os.path.exists(icon_path):
            self.create_default_icon(icon_path)

        # Add the main action
        self.add_action(
            icon_path,
            text=self.tr(u'🗺️ Raster & YOLO Loader'),
            callback=self.run,
            status_tip=self.tr(u'Load raster files and process with YOLO'),
            whats_this=self.tr(u'Open the Raster File Loader with YOLO Object Detection'),
            parent=self.iface.mainWindow())
            
        # Add separator and additional actions if needed
        self.toolbar.addSeparator()
        
        # You can add more actions here
        # self.add_quick_load_action()
        
        self.first_start = True

    def add_quick_load_action(self):
        """Add a quick load action to the toolbar"""
        icon_path = os.path.join(self.plugin_dir, 'quick_load_icon.png')
        
        # Create quick load icon if it doesn't exist
        if not os.path.exists(icon_path):
            self.create_quick_load_icon(icon_path)
            
        self.add_action(
            icon_path,
            text=self.tr(u'📁 Quick Load Folder'),
            callback=self.quick_load_folder,
            status_tip=self.tr(u'Quickly load all rasters from a folder'),
            whats_this=self.tr(u'Select a folder to quickly load all raster files'),
            add_to_menu=False,  # Only in toolbar, not in menu
            parent=self.iface.mainWindow())

    def create_default_icon(self, icon_path):
        """Create a default icon programmatically"""
        from qgis.PyQt.QtGui import QPixmap, QPainter, QColor, QFont
        from qgis.PyQt.QtCore import QRect
        
        # Create a 24x24 pixel icon
        pixmap = QPixmap(24, 24)
        pixmap.fill(QColor(76, 175, 80))  # Green background
        
        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))  # White text
        painter.setFont(QFont('Arial', 10, QFont.Bold))
        
        # Draw "RL" for Raster Loader
        painter.drawText(QRect(0, 0, 24, 24), 0x84, "RL")  # Qt.AlignCenter
        painter.end()
        
        pixmap.save(icon_path)

    def create_quick_load_icon(self, icon_path):
        """Create a quick load icon"""
        from qgis.PyQt.QtGui import QPixmap, QPainter, QColor, QFont
        from qgis.PyQt.QtCore import QRect
        
        pixmap = QPixmap(24, 24)
        pixmap.fill(QColor(33, 150, 243))  # Blue background
        
        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont('Arial', 10, QFont.Bold))
        
        # Draw "QL" for Quick Load
        painter.drawText(QRect(0, 0, 24, 24), 0x84, "QL")
        painter.end()
        
        pixmap.save(icon_path)

    def quick_load_folder(self):
        """Quick load all rasters from a selected folder"""
        from qgis.PyQt.QtWidgets import QFileDialog, QMessageBox
        from qgis.core import QgsRasterLayer, QgsProject
        import glob
        
        # Select folder
        folder = QFileDialog.getExistingDirectory(
            self.iface.mainWindow(),
            "Select Folder Containing Raster Files",
            ""
        )
        
        if not folder:
            return
            
        # Find all raster files
        raster_extensions = ['*.tif', '*.tiff', '*.TIF', '*.TIFF']
        raster_files = set()
        
        for ext in raster_extensions:
            pattern = os.path.join(folder, ext)
            raster_files.update(glob.glob(pattern))
        
        raster_files = sorted(list(raster_files))
        
        if not raster_files:
            QMessageBox.warning(
                self.iface.mainWindow(),
                "No Rasters Found",
                "No raster files (.tif/.tiff) found in the selected folder."
            )
            return
        
        # Load all rasters
        added_count = 0
        for raster_file in raster_files:
            filename = os.path.basename(raster_file)
            layer_name = os.path.splitext(filename)[0]
            
            raster_layer = QgsRasterLayer(raster_file, layer_name)
            if raster_layer.isValid():
                QgsProject.instance().addMapLayer(raster_layer)
                added_count += 1
        
        QMessageBox.information(
            self.iface.mainWindow(),
            "Quick Load Complete",
            f"Successfully loaded {added_count} raster files from:\n{folder}"
        )

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&File Loader'),
                action)
        
        # Remove the toolbar
        del self.toolbar

    def run(self):
        """Run method that performs all the real work"""
        # Create the dialog with elements and keep reference
        if self.first_start == True:
            self.first_start = False
            self.dlg = FileLoaderDialog(self.iface)

        # Show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        
        if result:
            pass  # Dialog was accepted